# TeamsFx files
env/.env.*.user
env/.env.local
.localConfigs
build
appPackage/build

# dependencies
node_modules/

# misc
.env
.deployment
.DS_Store

# build
dist/
