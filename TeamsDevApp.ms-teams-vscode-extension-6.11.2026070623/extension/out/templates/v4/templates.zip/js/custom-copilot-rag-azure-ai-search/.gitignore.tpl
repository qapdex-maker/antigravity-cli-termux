# TeamsFx files
env/.env.*.user
env/.env.local
.localConfigs
.localConfigs.playground
.notification.localstore.json
.notification.playgroundstore.json
appPackage/build

# dependencies
node_modules/

# misc
.env
.deployment
.DS_Store

# build
lib/

# devTools
devTools/
